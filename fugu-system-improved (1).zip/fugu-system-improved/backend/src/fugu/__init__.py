"""Fugu backend application package."""
